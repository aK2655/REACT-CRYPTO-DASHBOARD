import React from "react";
import "./mcards.css";
import SingleCard from "./SingleCrad";
import cardsData from "./cardsData";

const MiddleCards = () => {
  return (
    <div>
      <section className="middle">
        {/* CARDS STARTS */}
        <div className="cards">
          {cardsData.map((cardData, index) => (
            <SingleCard key={index} {...cardData} />
          ))}
        </div>
        {/* CARDS END */}
      </section>
    </div>
  );
};

export default MiddleCards;
