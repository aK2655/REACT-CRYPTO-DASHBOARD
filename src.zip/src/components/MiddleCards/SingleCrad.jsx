import React from "react";

const SingleCard = ({
  imgSrc,
  altText,
  title,
  visaPic,
  cardNumber,
  chipSrc,
  cardHolder,
  expiry,
  cvv,
}) => {
  return (
    <div className="card">
      <div className="top">
        <div className="left">
          <img src={imgSrc} alt={altText} />
          <h2>{title}</h2>
        </div>
        <img src={visaPic} className="right" alt="visa" />
      </div>
      <div className="middle">
        <h1>{cardNumber}</h1>
        <div className="chip">
          <img src={chipSrc} alt="chip" />
        </div>
      </div>
      <div className="bottom">
        <div className="left">
          <small>Card Holder</small>
          <h5>{cardHolder}</h5>
        </div>
        <div className="right">
          <div className="expiry">
            <small>Expiry</small>
            <h5>{expiry}</h5>
          </div>
          <div className="cvv">
            <small>CVV</small>
            <h5>{cvv}</h5>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SingleCard;
