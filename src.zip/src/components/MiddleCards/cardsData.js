
const cardsData = [
  {
    imgSrc: "./images/BTC.png",
    altText: "btc",
    title: "BTC",
    visaPic: "./images/visa.png",
    cardNumber: "$527,179",
    chipSrc: "./images/card chip.png",
    cardHolder: "RODNEY",
    expiry: "01/24",
    cvv: "247",
  },
  {
    imgSrc: "./images/ETH.png",
    altText: "ETH",
    title: "ETH",
    visaPic: "./images/master card.png",
    cardNumber: "$27,199",
    chipSrc: "./images/card chip.png",
    cardHolder: "SHEEY",
    expiry: "08/23",
    cvv: "202",
  },
  {
    imgSrc: "./images/BTC.png",
    altText: "btc",
    title: "BTC",
    visaPic: "./images/visa.png",
    cardNumber: "$76,176",
    chipSrc: "./images/card chip.png",
    cardHolder: "ALJAUZY",
    expiry: "04/24",
    cvv: "245",
  },
];

export default cardsData;
