import React from "react";
import "./investments.css";
import Investments from "./Investments";

const Investment = () => {
  return (
    <div>
      <section className="right">
        <Investments />
      </section>
    </div>
  );
};

export default Investment;
