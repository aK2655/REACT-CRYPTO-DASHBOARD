import React from "react";
import SingleInvestment from "./SingleInvestment";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";

const Investments = () => {
  return (
    <div className="investments">
      <div className="header">
        <h2>Investments</h2>
        <a href="#">
          More
          <span>
            <ArrowForwardIosIcon className="arrow" />
          </span>
        </a>
      </div>
      <SingleInvestment
        imgSrc="./images/uniliver.png"
        name="Uniliver"
        date="22 Jul, 2023"
        time="0914Hrs"
        bonds="1236"
        amount="$23,000"
        change="-4.27%"
      />
      <SingleInvestment
        imgSrc="./images/tesla.png"
        name="Tesla"
        date="12 Jul, 2022"
        time="1025Hrs"
        bonds="1543"
        amount="$57,000"
        change="+14.27%"
      />
      <SingleInvestment
        imgSrc="./images/monster.png"
        name="Monster"
        date="27 Aug, 2023"
        time="1814Hrs"
        bonds="2736"
        amount="$26,783"
        change="+9.27%"
      />
      <SingleInvestment
        imgSrc="./images/mcdonalds.png"
        name="McDonalds"
        date="17 Aug, 2023"
        time="1814Hrs"
        bonds="2676"
        amount="$19,289"
        change="-5.27%"
      />
    </div>
  );
};

export default Investments;
