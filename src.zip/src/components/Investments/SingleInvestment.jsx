import React from "react";

const SingleInvestment = (props) => {
  return (
    <div className="investment">
      <img src={props.imgSrc} alt={props.name} />
      <h4>{props.name}</h4>
      <div className="date-time">
        <p>{props.date}</p>
        <small className="text-muted">{props.time}</small>
      </div>
      <div className="bonds">
        <p>{props.bonds}</p>
        <small className="text-muted">Bonds</small>
      </div>
      <div className="amount">
        <h4>{props.amount}</h4>
        <small className={props.change.includes("-") ? "danger" : "success"}>
          {props.change}
        </small>
      </div>
    </div>
  );
};

export default SingleInvestment;
