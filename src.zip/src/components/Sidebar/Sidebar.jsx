import React, { useState } from "react";
import "./sidebar.css";
import CloseIcon from "@mui/icons-material/Close";
import CurrencyExchangeIcon from "@mui/icons-material/CurrencyExchange";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import PaymentIcon from "@mui/icons-material/Payment";
import PieChartIcon from "@mui/icons-material/PieChart";
import MessageIcon from "@mui/icons-material/Message";
import HelpCenterIcon from "@mui/icons-material/HelpCenter";
import SettingsIcon from "@mui/icons-material/Settings";
import UpdateIcon from "@mui/icons-material/Update";

const Sidebar = ({ isSidebarVisible, toggleSidebar }) => {
  return (
    <div>
      <aside className={`sidebar ${isSidebarVisible ? 'show-sidebar' : ''}`}>
        <button id="close-btn" onClick={toggleSidebar}>
          <span>
            <CloseIcon />
          </span>
        </button>
        <div className="sidebar">
          <a href="#" className="active">
            <span>
              <CloseIcon />
            </span>
            <h4>Dashboard</h4>
          </a>
          <a href="#">
            <span>
              <CurrencyExchangeIcon />
            </span>
            <h4>Exchange</h4>
          </a>
          <a href="#">
            <span>
              <AccountBalanceWalletIcon />
            </span>
            <h4>Wallet</h4>
          </a>
          <a href="#">
            <span>
              <PaymentIcon />
            </span>
            <h4>Transactions</h4>
          </a>
          <a href="#">
            <span>
              <PieChartIcon />
            </span>
            <h4>Analytics</h4>
          </a>
          <a href="#">
            <span>
              <MessageIcon />
            </span>
            <h4>Messages</h4>
          </a>
          <a href="#">
            <span>
              <HelpCenterIcon />
            </span>
            <h4>Help Center</h4>
          </a>
          <a href="#">
            <span>
              <SettingsIcon />
            </span>
            <h4>Settings</h4>
          </a>
        </div>
        <div className="updates">
          <span>
            <UpdateIcon />
          </span>
          <h4>Updates Available</h4>
          <p>Security Updates</p>
          <p>General Updates</p>
          <a href="#">Update Now</a>
        </div>
      </aside>
    </div>
  );
};

export default Sidebar;
