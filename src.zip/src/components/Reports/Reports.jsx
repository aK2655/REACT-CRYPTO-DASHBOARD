import React, { useState } from "react";
import "./report.css";
import SingleReport from "./SingleReport";

const Reports = () => {
  const [openReportIndex, setOpenReportIndex] = useState(null);

  const allReports = [
    {
      title: "Income",
      amount: "$228,200",
      percentage: 58.21,
      comparison: "$156,748 last month",
    },
    {
      title: "Expenses",
      amount: "$5,640",
      percentage: -2.37,
      comparison: "$21,738 last month",
    },
    {
      title: "Cashback",
      amount: "$9,221",
      percentage: -4.21,
      comparison: "$23,203 last month",
    },
    {
      title: "Savings",
      amount: "$91,221",
      percentage: 24.21,
      comparison: "$51,973 last month",
    },
  ];

  const handleReportClick = (index) => {
    setOpenReportIndex(index);
  };

  return (
    <div>
      <section className="middle">
        <div className="monthly-report">
          {allReports.map((report, index) => (
            <div key={index} onClick={() => handleReportClick(index)}>
              {openReportIndex === index && <SingleReport {...report} />}
              {openReportIndex !== index && (
                <div className="report">
                  <h3>{report.title}</h3>
                  <p className="text-muted">Click to view details</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Reports;
