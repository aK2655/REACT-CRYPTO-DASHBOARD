import React from "react";

const SingleReport = ({ title, amount, percentage, comparison }) => {
  return (
    <div className="report">
      <h3>{title}</h3>
      <div>
        <details>
          <summary>
            <h1>{amount}</h1>
            <h6 className={percentage >= 0 ? "success" : "danger"}>
              {percentage >= 0
                ? `+${percentage.toFixed(2)}%`
                : `${percentage.toFixed(2)}%`}
            </h6>
          </summary>
        </details>
        <p className="text-muted">compared to {comparison} last month</p>
      </div>
    </div>
  );
};

export default SingleReport;
