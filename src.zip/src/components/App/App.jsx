import React, { useState } from "react";
import "./app.css";
import Navbar from "../Navbar/Navbar";
import Sidebar from "../Sidebar/Sidebar";
import MiddleHeader from "../MiddleHeader/MiddleHeader";
import MiddleCards from "../MiddleCards/MiddleCards";
import Reports from "../Reports/Reports";
import FastPayment from "../FastPayment/FastPayment";
import { Canvas } from "../Canva/Canvas";
import Investment from "../Investments/Investment";
import Transactions from "../Transactions/Transactions";

const App = () => {
  const [isSidebarVisible, setSidebarVisible] = useState(false);

  const toggleSidebar = () => {
    setSidebarVisible((prevVisible) => !prevVisible);
  };

  return (
    <div>
      <Navbar toggleSidebar={toggleSidebar} />
      <main>
        <Sidebar
          isSidebarVisible={isSidebarVisible}
          toggleSidebar={toggleSidebar}
        />
        <section>
          <MiddleHeader />
          <MiddleCards />
          <Reports />
          <FastPayment />
          <Canvas />
        </section>
        <section>
          <Investment />
          <Transactions />
        </section>
      </main>
    </div>
  );
};

export default App;
