import React from "react";
import "./mheader.css";

const date = new Date();
const formattedDate = date.toLocaleDateString("en-US");

const MiddleHeader = () => {
  return (
    <div>
      <section className="middle">
        <div className="header">
          <h1>Overview</h1>
          <p>{formattedDate}</p>
        </div>
      </section>
    </div>
  );
};

export default MiddleHeader;
