import React from "react";
import "./fast.css";
import AddIcon from '@mui/icons-material/Add';

const FastPayment = () => {
  return (
    <div>
      <section className="middle">
        {/* FAST PAYMENTS STARTS */}
        <div className="fast-payment">
          <h2>Fast Payments</h2>
          <div className="badges">
            <div className="badge">
              <span><AddIcon /></span>
            </div>
            <div className="badge">
              <span className="bg-success" />
              <div>
                <h5>Internet</h5>
                <h4>$6,000</h4>
              </div>
            </div>
            <div className="badge">
              <span className="bg-primary" />
              <div>
                <h5>Transport</h5>
                <h4>$100</h4>
              </div>
            </div>
            <div className="badge">
              <span className="bg-danger" />
              <div>
                <h5>Rent</h5>
                <h4>$8,000</h4>
              </div>
            </div>
            <div className="badge">
              <span className="bg-primary" />
              <div>
                <h5>Food</h5>
                <h4>$8,000</h4>
              </div>
            </div>
            <div className="badge">
              <span className="bg-primary" />
              <div>
                <h5>Airtime</h5>
                <h4>$100</h4>
              </div>
            </div>
            <div className="badge">
              <span className="bg-purple" />
              <div>
                <h5>Maintenance</h5>
                <h4>$1000</h4>
              </div>
            </div>
            <div className="badge">
              <span className="bg-success" />
              <div>
                <h5>Leisure</h5>
                <h4>$5000</h4>
              </div>
            </div>
          </div>
        </div>
        {/* FAST PAYMENTS ENDS */}
      </section>
    </div>
  );
};

export default FastPayment;
