import React from "react";
import TransactionService from "./TransactionService";
import TransactionCardDetails from "./TransactionCardDetails";

const Transaction = ({ transaction }) => (
  <div className="transaction">
    <TransactionService
      iconClass={transaction.serviceIcon}
      serviceName={transaction.serviceName}
      date={transaction.date}
      iconColor={transaction.iconColor}
      iconbackg={transaction.iconbglight}
    />
    <TransactionCardDetails
      cardIcon={transaction.cardIcon}
      cardType={transaction.cardType}
      cardBackground={transaction.cardBackground}
      cardNumber={transaction.cardNumber}
    />
    <h4>${transaction.amount}</h4>
  </div>
);

export default Transaction;
