import React from "react";
import HeadphonesIcon from "@mui/icons-material/Headphones";
import ShoppingBagIcon from "@mui/icons-material/ShoppingBag";
import RestaurantIcon from "@mui/icons-material/Restaurant";
import SportsEsportsIcon from "@mui/icons-material/SportsEsports";
import MedicationIcon from "@mui/icons-material/Medication";
import FitnessCenterIcon from "@mui/icons-material/FitnessCenter";

const transactionsData = [
  {
    serviceIcon: <HeadphonesIcon style={{ fontSize: 20 }} />,
    serviceName: "Music",
    date: "20.11.2023",
    cardIcon: "./images/visa.png",
    cardType: "Visa",
    cardBackground: "bg-danger",
    iconColor: "purple",
    iconbglight: "bg-purple-light",
    cardNumber: "*2783",
    amount: 57,
  },
  {
    serviceIcon: <ShoppingBagIcon style={{ fontSize: 20 }} />,
    serviceName: "Shopping",
    date: "20.11.2023",
    cardIcon: "./images/visa.png",
    cardType: "Visa",
    cardBackground: "bg-primary",
    iconColor: "purple",
    iconbglight: "bg-purple-light",
    cardNumber: "*2783",
    amount: 47,
  },
  {
    serviceIcon: <RestaurantIcon style={{ fontSize: 20 }} />,
    serviceName: "Restaurant",
    date: "20.11.2023",
    cardIcon: "./images/master card.png",
    cardType: "Visa",
    cardBackground: "bg-danger",
    iconColor: "success",
    iconbglight: "bg-success-light",
    cardNumber: "*2783",
    amount: 40,
  },
  {
    serviceIcon: <SportsEsportsIcon style={{ fontSize: 20 }} />,
    serviceName: "Games",
    date: "20.11.2023",
    cardIcon: "./images/visa.png",
    cardType: "Visa",
    cardBackground: "bg-danger",
    iconColor: "danger",
    iconbglight: "bg-danger-light",
    cardNumber: "*2783",
    amount: 124,
  },
  {
    serviceIcon: <MedicationIcon style={{ fontSize: 20 }} />,
    serviceName: "Medication",
    date: "20.11.2023",
    cardIcon: "./images/visa.png",
    cardType: "Visa",
    cardBackground: "bg-primary",
    iconColor: "danger",
    iconbglight: "bg-danger-light",
    cardNumber: "*2783",
    amount: 434,
  },
  {
    serviceIcon: <FitnessCenterIcon style={{ fontSize: 20 }} />,
    serviceName: "Fitness",
    date: "20.11.2023",
    cardIcon: "./images/master card.png",
    cardType: "Visa",
    cardBackground: "bg-dark",
    iconColor: "success",
    iconbglight: "bg-success-light",
    cardNumber: "*2783",
    amount: 234,
  },
];

export default transactionsData;
