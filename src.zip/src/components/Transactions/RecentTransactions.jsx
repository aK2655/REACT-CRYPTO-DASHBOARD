import React from "react";
import Transaction from "./Transaction";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";


const RecentTransactions = ({ alltransactions }) => (
  <div className="recent-transactions">
    <div className="header">
      <h2>Recent Transactions</h2>
      <a href="#">
        More <span><ArrowForwardIosIcon /></span>
      </a>
    </div>
    {alltransactions.map((transaction, index) => (
      <Transaction key={index} transaction={transaction} />
    ))}
  </div>
);

export default RecentTransactions;
