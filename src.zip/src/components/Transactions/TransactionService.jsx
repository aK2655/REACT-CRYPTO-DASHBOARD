import React from "react";

const iconStyle = {
  padding: "5px",
  borderRadius: "1rem",
  display: "flex",
  alignItems: "center",
};

const TransactionService = ({
  iconClass,
  serviceName,
  date,
  iconColor,
  iconbackg,
}) => (
  <div className="service">
    <div className={`icon ${iconbackg}`}>
      <span style={iconStyle} className={iconColor}>
        {iconClass}
      </span>
    </div>
    <div className="details">
      <h4>{serviceName}</h4>
      <p>{date}</p>
    </div>
  </div>
);

export default TransactionService;
