import React from "react";

const TransactionCardDetails = ({ cardIcon, cardType, cardBackground, cardNumber }) => (
  <div className="card-details">
    <div className={`card ${cardBackground}`}>
      <img src={cardIcon} alt={cardType} />
    </div>
    <div className="details">
      <p>{cardNumber}</p>
      <small className="text-muted">{cardType}</small>
    </div>
  </div>
);

export default TransactionCardDetails;
