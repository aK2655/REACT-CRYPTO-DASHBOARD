import React from "react";
import "./transaction.css";
import RecentTransactions from "./RecentTransactions";
import transactionsData from "./transactionsData";

const Transactions = () => {
  return (
    <div>
      <RecentTransactions alltransactions={transactionsData} />
    </div>
  );
};

export default Transactions;
