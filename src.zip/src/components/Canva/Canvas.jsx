import React from "react";
import "./canvas.css";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Line } from "react-chartjs-2";
import data from "./data";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export const options = {
  responsive: true,
  plugins: {
    legend: {
      position: "top",
    },
    title: {
      display: true,
      text: "Luxac This Year`s Graph",
    },
  },
};

export function Canvas() {
  return (
    <div>
      <section className="middle">
        <Line options={options} data={data} className="chart" />
      </section>
    </div>
  );
}
