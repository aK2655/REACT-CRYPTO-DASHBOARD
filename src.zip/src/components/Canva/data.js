const labels = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];

const data = {
  labels,
  datasets: [
    {
      label: "BTC",
      data: [
        67263, 17262, 50763, 12372, 20000, 23632, 21021, 28621, 23763, 21371,
        32761, 23732,
      ],
      borderColor: "red",
      borderWidth: 2,
    },
    {
      label: "ETH",
      data: [
        33833, 36762, 23484, 32722, 64137, 50000, 43248, 38721, 27378, 27849,
        70733, 72832,
      ],
      borderColor: "blue",
      borderWidth: 2,
    },
  ],
};

export default data;
