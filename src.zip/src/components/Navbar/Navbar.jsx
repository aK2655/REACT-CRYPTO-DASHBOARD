import React, { useState, useEffect } from "react";
import "./navbar.css";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";
import LightModeIcon from "@mui/icons-material/LightMode";
import DarkModeIcon from "@mui/icons-material/DarkMode";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import MenuIcon from "@mui/icons-material/Menu";

function Navbar({ toggleSidebar }) {
  const [darkTheme, setDarkTheme] = useState(false);

  const toggleTheme = () => {
    setDarkTheme(!darkTheme);
  };

  useEffect(() => {
    if (darkTheme) {
      document.body.classList.add("dark-theme");
    } else {
      document.body.classList.remove("dark-theme");
    }
  }, [darkTheme]);

  return (
    <nav>
      <div className="container">
        <img src="./images/luxac-logo.png" className="logo" alt="luxac-logo" />
        <div className="search-bar">
          <span>
            <SearchOutlinedIcon />
          </span>
          <input type="search" placeholder="Search" />
        </div>
        <div className="profile-area">
          <div
            className={`theme-btn ${darkTheme ? "dark-theme" : ""}`}
            onClick={toggleTheme}
          >
            <span className={!darkTheme ? "active" : ""}>
              <LightModeIcon />
            </span>
            <span className={darkTheme ? "active" : ""}>
              <DarkModeIcon />
            </span>
          </div>
          <div className="profile">
            <div className="profile-photo">
              <img src="./images/aljauzy.jpg" alt="aljauzy-luxac" />
            </div>
            <h5>Aljauzy</h5>
            <span>
              <ExpandMoreIcon />
            </span>
          </div>
          <button id="menu-btn">
            <span>
              <MenuIcon onClick={toggleSidebar} />
            </span>
          </button>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
